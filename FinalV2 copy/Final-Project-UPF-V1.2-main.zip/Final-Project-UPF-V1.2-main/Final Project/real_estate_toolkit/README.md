Information Concerning Datas
- The datas are in the data_files folder
    path(real_estate_toolkit/src/data/data_files)
